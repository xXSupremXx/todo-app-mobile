function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-item-view-edit-item-view-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-item-view/edit-item-view.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/edit-item-view/edit-item-view.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppEditItemViewEditItemViewPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <div *ngIf=\"currentItem\" class=\"toolbar\">\n      <ion-back-button class=\"backbutton\"></ion-back-button>\n      <ion-title >edit \"{{currentItem.name.trim()}}\"</ion-title>\n    </div>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"container\" *ngIf=\"currentItem\">\n    <ion-card class=\"edit-name\">\n      <div class=\"input\">\n        <ion-item>\n          <ion-input #name value=\"{{currentItem.name}}\"></ion-input>\n        </ion-item>\n      </div>\n    </ion-card>\n    <ion-card class=\"edit-description\">\n      <div class=\"input\">\n        <ion-item>\n          <ion-textarea class=\"text\" #desc value=\"{{currentItem.description}}\"></ion-textarea>\n        </ion-item>\n      </div>\n    </ion-card>\n    <ion-card class=\"edit-date\">\n      <div>\n        <ion-item>\n          <ion-datetime #date class=\"date\" displayFormat=\"MMM DD, YYYY\" value=\"{{currentItem.date | date}}\"></ion-datetime>\n        </ion-item>\n      </div>\n    </ion-card>\n    <ion-button class=\"saveButton\" (click)=\"save(name.value, desc.value, date.value)\">Save</ion-button>\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/edit-item-view/edit-item-view-routing.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/edit-item-view/edit-item-view-routing.module.ts ***!
    \*****************************************************************/

  /*! exports provided: EditItemViewPageRoutingModule */

  /***/
  function srcAppEditItemViewEditItemViewRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditItemViewPageRoutingModule", function () {
      return EditItemViewPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _edit_item_view_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./edit-item-view.page */
    "./src/app/edit-item-view/edit-item-view.page.ts");

    var routes = [{
      path: '',
      component: _edit_item_view_page__WEBPACK_IMPORTED_MODULE_3__["EditItemViewPage"]
    }];

    var EditItemViewPageRoutingModule = function EditItemViewPageRoutingModule() {
      _classCallCheck(this, EditItemViewPageRoutingModule);
    };

    EditItemViewPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], EditItemViewPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/edit-item-view/edit-item-view.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/edit-item-view/edit-item-view.module.ts ***!
    \*********************************************************/

  /*! exports provided: EditItemViewPageModule */

  /***/
  function srcAppEditItemViewEditItemViewModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditItemViewPageModule", function () {
      return EditItemViewPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _edit_item_view_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./edit-item-view-routing.module */
    "./src/app/edit-item-view/edit-item-view-routing.module.ts");
    /* harmony import */


    var _edit_item_view_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./edit-item-view.page */
    "./src/app/edit-item-view/edit-item-view.page.ts");

    var EditItemViewPageModule = function EditItemViewPageModule() {
      _classCallCheck(this, EditItemViewPageModule);
    };

    EditItemViewPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _edit_item_view_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditItemViewPageRoutingModule"]],
      declarations: [_edit_item_view_page__WEBPACK_IMPORTED_MODULE_6__["EditItemViewPage"]]
    })], EditItemViewPageModule);
    /***/
  },

  /***/
  "./src/app/edit-item-view/edit-item-view.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/edit-item-view/edit-item-view.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppEditItemViewEditItemViewPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".toolbar {\n  display: flex;\n  flex-direction: row;\n  justify-content: flex-start;\n}\n\n.edit-name {\n  height: 2.6rem;\n}\n\n.edit-description {\n  height: 5rem;\n}\n\n.edit-date {\n  height: 2.6rem;\n}\n\n.text {\n  height: 6rem;\n}\n\n.date {\n  padding-left: 0rem;\n}\n\n.saveButton {\n  width: 90%;\n  margin-left: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZWRpdC1pdGVtLXZpZXcvQzpcXGRldlxcQW5ndWxhclxcaW9uaWMtcHJvamVjdHNcXFRvRG8tQXBwL3NyY1xcYXBwXFxlZGl0LWl0ZW0tdmlld1xcZWRpdC1pdGVtLXZpZXcucGFnZS5zY3NzIiwic3JjL2FwcC9lZGl0LWl0ZW0tdmlldy9lZGl0LWl0ZW0tdmlldy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtBQ0NKOztBRENBO0VBQ0ksY0FBQTtBQ0VKOztBREFBO0VBQ0ksWUFBQTtBQ0dKOztBREFBO0VBQ0ksY0FBQTtBQ0dKOztBREFBO0VBQ0ksWUFBQTtBQ0dKOztBREFBO0VBQ0ksa0JBQUE7QUNHSjs7QURBQTtFQUNJLFVBQUE7RUFDQSxlQUFBO0FDR0oiLCJmaWxlIjoic3JjL2FwcC9lZGl0LWl0ZW0tdmlldy9lZGl0LWl0ZW0tdmlldy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhcntcclxuICAgIGRpc3BsYXk6ZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XHJcbn1cclxuLmVkaXQtbmFtZXtcclxuICAgIGhlaWdodDogMi42cmVtO1xyXG59XHJcbi5lZGl0LWRlc2NyaXB0aW9ue1xyXG4gICAgaGVpZ2h0OiA1cmVtO1xyXG59XHJcblxyXG4uZWRpdC1kYXRle1xyXG4gICAgaGVpZ2h0OiAyLjZyZW07XHJcbn1cclxuXHJcbi50ZXh0e1xyXG4gICAgaGVpZ2h0OiA2cmVtO1xyXG59XHJcblxyXG4uZGF0ZXtcclxuICAgIHBhZGRpbmctbGVmdDogMHJlbTtcclxufVxyXG5cclxuLnNhdmVCdXR0b257XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xyXG59IiwiLnRvb2xiYXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XG59XG5cbi5lZGl0LW5hbWUge1xuICBoZWlnaHQ6IDIuNnJlbTtcbn1cblxuLmVkaXQtZGVzY3JpcHRpb24ge1xuICBoZWlnaHQ6IDVyZW07XG59XG5cbi5lZGl0LWRhdGUge1xuICBoZWlnaHQ6IDIuNnJlbTtcbn1cblxuLnRleHQge1xuICBoZWlnaHQ6IDZyZW07XG59XG5cbi5kYXRlIHtcbiAgcGFkZGluZy1sZWZ0OiAwcmVtO1xufVxuXG4uc2F2ZUJ1dHRvbiB7XG4gIHdpZHRoOiA5MCU7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/edit-item-view/edit-item-view.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/edit-item-view/edit-item-view.page.ts ***!
    \*******************************************************/

  /*! exports provided: EditItemViewPage */

  /***/
  function srcAppEditItemViewEditItemViewPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditItemViewPage", function () {
      return EditItemViewPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _todo_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../todo.service */
    "./src/app/todo.service.ts");

    var EditItemViewPage = /*#__PURE__*/function () {
      function EditItemViewPage(location, route, todoService) {
        _classCallCheck(this, EditItemViewPage);

        this.location = location;
        this.route = route;
        this.todoService = todoService;
        this.backButton = "cancel";
      }

      _createClass(EditItemViewPage, [{
        key: "getItemId",
        value: function getItemId() {
          var _this = this;

          var id = this.route.snapshot.paramMap.get('id'); //console.log(id);

          this.todoService.getItem(id).subscribe(function (item) {
            _this.currentItem = item;
            console.log(_this.currentItem.date); //console.log(this.currentItem);
          }); //console.log(this.currentItem);
        }
      }, {
        key: "save",
        value: function save(name, description, strdate) {
          //console.log(this.currentItem.id);
          var date = new Date(strdate);

          if (name != '') {
            this.currentItem.name = name;
          }

          if (description != '') {
            this.currentItem.description = description;
          }

          if (strdate != '') {
            this.currentItem.date = date.getTime();
          }

          this.todoService.updateItem(this.currentItem).subscribe();
          this.backButton = "back";
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.location.back();
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.getItemId();
        }
      }]);

      return EditItemViewPage;
    }();

    EditItemViewPage.ctorParameters = function () {
      return [{
        type: _angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _todo_service__WEBPACK_IMPORTED_MODULE_4__["TodoService"]
      }];
    };

    EditItemViewPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-edit-item-view',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./edit-item-view.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-item-view/edit-item-view.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./edit-item-view.page.scss */
      "./src/app/edit-item-view/edit-item-view.page.scss"))["default"]]
    })], EditItemViewPage);
    /***/
  }
}]);
//# sourceMappingURL=edit-item-view-edit-item-view-module-es5.js.map